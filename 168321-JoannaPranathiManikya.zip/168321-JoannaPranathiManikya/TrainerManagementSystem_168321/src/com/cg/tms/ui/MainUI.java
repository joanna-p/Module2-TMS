package com.cg.tms.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

import org.apache.log4j.PropertyConfigurator;

import com.cg.tms.exception.TMSException;
import com.cg.tms.model.TrainerDetails;
import com.cg.tms.service.TrainerService;
import com.cg.tms.service.TrainerServiceImpl;

public class MainUI {

	public static void main(String[] args) {
		PropertyConfigurator.configure("resource/log4j.properties");
		boolean doflag=false;
		String technology = null;
		String location = null;
		List<TrainerDetails> list= new ArrayList<>();
		System.out.println("Trainer Management System");
		System.out.println("1. Search trainers based on location and technology");
		System.out.println("2. Exit");
		System.out.println("Choose the value");
		do{
			Scanner scanner = new Scanner(System.in);
			int choice;
			
			choice = scanner.nextInt();
			scanner.nextLine();
			switch (choice) {
			case 1:
				do{
					scanner = new Scanner(System.in);
				System.out.println("Enter the Technology");
				 technology = scanner.nextLine();
				String reGexTech="[a-z]*";
				boolean vflag = Pattern.matches(reGexTech, technology);
				if(vflag==true){
					doflag=true;
				}
		    	   else
		    	   {	   doflag = false;
		    		   System.err.println("Invalid Techn name( Please enter in smaller case)");}
				}while(!doflag);
				
				do{
					scanner = new Scanner(System.in);
				System.out.println("Enter the Location");
				 location = scanner.nextLine();
				
				 String reGexLoc="[A-Z]{1}[a-z]*";
		    	   boolean input=Pattern.matches(reGexLoc, location);
		    	   if(input==true)
		    	   {
		    		doflag=true;
		    	   }
		    	   else
		    		   {doflag = false;
		    		   System.err.println("invalid location name(first letter caps)");}
				}while(!doflag);
				
				TrainerService service = new TrainerServiceImpl();
				try {
					list = service.getTrainerDetail(technology,location);
					if(list.isEmpty())
					{
						System.err.println("Sorry No trainers available for the given criteria");
						
					}
					else{
					System.out.println("ID" + "        " + "name" + "           " + "location"
							+ "        " + "designation" + "        " + "technology" + "        "
							+ "contactno");
					for (TrainerDetails trainer : list) {
						System.out.println(trainer.getId()+"----"+trainer.getName()+"----"+trainer.getLocation()+"-----"+
					trainer.getDesignation()+"----"+trainer.getTechnology()+"----"+trainer.getContactNo());
					}
				 doflag=true;
					}
					
				} catch (TMSException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}				
				
				break;
				
			case 2:
				System.out.println("Thank you");
				System.exit(0);;
				break;

			default:
				break;
			}
			System.out.println("");
			scanner.close();
		}while(!doflag);
		
	}

}
