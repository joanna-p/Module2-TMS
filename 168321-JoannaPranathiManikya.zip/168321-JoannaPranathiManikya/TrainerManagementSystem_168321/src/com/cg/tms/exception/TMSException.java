package com.cg.tms.exception;

public class TMSException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4655431240642387188L;

	public TMSException(String message){
		super(message);
		
	}

	
}
