package com.cg.tms.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.tms.dao.TrainerDao;
import com.cg.tms.dao.TrainerDaoImpl;
import com.cg.tms.exception.TMSException;
import com.cg.tms.model.TrainerDetails;

public class TrainerDaoImplTest {
	TrainerDao trainerDao=null;
	@Before
	public void setUp() throws Exception {
		trainerDao=new TrainerDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		trainerDao = null;
	}

	@Test
	public void testGetTrainerDetail() {
		int value;
		try {
			
			List<TrainerDetails> list=trainerDao.getTrainerDetail("mainframes","Bangalore");
			if(list.isEmpty())
				value=0;
			else
				value=1;
			assertEquals(1, value);
		} catch (TMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
