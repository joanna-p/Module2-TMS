package com.cg.tms.dao;

import java.util.List;

import com.cg.tms.exception.TMSException;
import com.cg.tms.model.TrainerDetails;

public interface TrainerDao {

	List<TrainerDetails> getTrainerDetail(String technology, String location) throws TMSException;

}
