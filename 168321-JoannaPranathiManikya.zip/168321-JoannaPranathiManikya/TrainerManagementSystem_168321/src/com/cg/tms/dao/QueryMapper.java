package com.cg.tms.dao;

public interface QueryMapper {
 public static final String getTrainerDetails="select * from trainer_details where technology=? and location=?";
}
