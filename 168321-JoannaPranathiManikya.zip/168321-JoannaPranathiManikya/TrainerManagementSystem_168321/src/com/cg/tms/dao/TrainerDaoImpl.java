package com.cg.tms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



import org.apache.log4j.Logger;

import com.cg.tms.exception.TMSException;
import com.cg.tms.model.TrainerDetails;
import com.cg.tms.utility.JdbcUtility;

public class TrainerDaoImpl implements TrainerDao {
	static Logger logger = Logger.getLogger(TrainerDaoImpl.class);
Connection connection= null;
PreparedStatement statement = null;
ResultSet resultSet = null;

	@Override
	public List<TrainerDetails> getTrainerDetail(String technology,
			String location) throws TMSException {
		
		logger.info("Inside get trainer details");
		
		List<TrainerDetails> list = new ArrayList<>();
		connection = JdbcUtility.getConnection();
		
		try {
			
			
			statement =connection.prepareStatement(QueryMapper.getTrainerDetails);
			logger.info("statement created");
			
			statement.setString(1,technology);
			statement.setString(2, location);
			
			resultSet=statement.executeQuery();
			logger.info("resultset "+resultSet);
			
			while(resultSet.next())
			{
				logger.info("inside while loop in result Set");	
				int id = resultSet.getInt(1);
				String name = resultSet.getString(2);
				String contactNo = resultSet.getString(3);
				String locations = resultSet.getString(4);
				String designation = resultSet.getString(5);
				String tech = resultSet.getString(6);
				
				TrainerDetails trainer=new TrainerDetails();
				trainer.setTechnology(tech);
				trainer.setLocation(locations);
				trainer.setContactNo(contactNo);
				trainer.setDesignation(designation);
				trainer.setName(name);
				trainer.setId(id);
				
				
				list.add(trainer);
				
				
				logger.info("Respose from RESULT SET" +list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			logger.error(e.getStackTrace());
		}	
		try {
			resultSet.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(e.getStackTrace());
		}
		try {
			statement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(e.getStackTrace());
		}
		try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(e.getStackTrace());
		}
		logger.info("Ends getDetails");
		return list;
		
	}

}
